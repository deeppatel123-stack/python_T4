from django.db import models
from django.contrib.auth.models import User

class Player(models.Model):
    name = models.CharField(max_length=100)
    innings = models.IntegerField()
    runs = models.IntegerField()

    def __str__(self):
        return self.name
    
class Student(models.Model):
    name = models.CharField(max_length=100)
    roll_number = models.CharField(max_length=20, unique=True)
    email = models.EmailField(unique=True,default="student@exam.com")
    phone = models.CharField(max_length=15,blank=True,null=True)
    department = models.CharField(max_length=100, default="Computer Science")
    status = models.CharField(max_length=50, default='Active')
    gpa = models.FloatField()
    enrollment_date = models.DateField(auto_now_add=True)

    def __str__(self):
        return f"{self.name} ({self.roll_number})"