from django.contrib import admin
from .models import Player,Student

admin.site.register(Player)
# Register your models here.
admin.site.register(Student)