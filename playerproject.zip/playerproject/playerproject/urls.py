"""
URL configuration for playerproject project.

The `urlpatterns` list routes URLs to views. For more information please see:
    https://docs.djangoproject.com/en/6.0/topics/http/urls/
Examples:
Function views
    1. Add an import:  from my_app import views
    2. Add a URL to urlpatterns:  path('', views.home, name='home')
Class-based views
    1. Add an import:  from other_app.views import Home
    2. Add a URL to urlpatterns:  path('', Home.as_view(), name='home')
Including another URLconf
    1. Import the include() function: from django.urls import include, path
    2. Add a URL to urlpatterns:  path('blog/', include('blog.urls'))
"""
from django.contrib import admin
from django.urls import path
from playerapp import views as playerViews

urlpatterns = [
    path('admin/', admin.site.urls),
    path("",playerViews.home,name='home'),
    path('welcome/',playerViews.welcome,name='welcome'),
    path('add/',playerViews.add,name='add'),
    
    path('home/',playerViews.home_view,name='home_student'),
    path('add_student/',playerViews.add_student_view,name='add_student'),
    path('edit_student/<int:pk>/',playerViews.edit_student_view,name='edit_student'),
    path('delete_student/<int:pk>/delete',playerViews.delete_student_view,name='delete_student'),

    path('signup/',playerViews.signup_view, name='signup'),
    path('login/',playerViews.login_view, name='login'),
    path('logout/',playerViews.logout_view, name='logout'),

    # path('edit/<int:pk>/',playerViews.edit_player, name='edit'),
    # path('delete/<int:pk>/',playerViews.delete_player, name='delete')
]
